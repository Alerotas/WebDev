<?php

class user extends CI_controller{


	function index() {
		$this->load->model('users_model');
		$tablesample = $this->users_model->all();
		$data = array();
		$data['tablesample'] = $tablesample;
		$this->load->view('list',$data);
	}

	function create(){

	$this->load->model('users_model');
	$this->form_validation->set_rules('name', 'Name', 'required');
	$this->form_validation->set_rules('age', 'Age', 'required');
	$this->form_validation->set_rules('status', 'Status', 'required');
	$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
	

	if ($this->form_validation->run() == false) {
			$this->load->view('create');
		 
	}else{

		$formArray = array();
		$formArray['name'] = $this->input->post('name');
		$formArray['age'] = $this->input->post('age');
		$formArray['status'] = $this->input->post('status');
		$formArray['email'] = $this->input->post('email');
		$formArray['created_at'] = date('Y-m-d');
		$this->users_model->create($formArray);
		$this->session->set_flashdata('success', 'Record added successfully!');
		redirect(base_url().'index.php/user/index');
	}

}

function edit($user_id)
{
	$this->load->model('users_model');
	$users =$this->users_model->getUser($user_id);
	$data =array();
	$data['user'] = $user;


	$this->form_validation->set_rules('name', 'Name', 'required');
	$this->form_validation->set_rules('age', 'Age', 'required');
	$this->form_validation->set_rules('status', 'Status', 'required');
	$this->form_validation->set_rules('email', 'Email', 'required|valid_email');

	if($this->form_validation->run() == false){
		$this->load->view('edit',$data);
	}else {
		// Update user record 
		$formArray= array();
		$formArray['name'] = $this->input->post('name');
		$formArray['age'] = $this->input->post('age');
		$formArray['status'] = $this->input->post('status');
		$formArray['email'] = $this->input->post('email');
		$this->users_model->updateUser($user_id,$formArray);
		$this->session->set_flashdata('success', 'Record update successfully!');
		redirect(base_url().'index.php/user/index'); 
	}
	

}
	function delete($user_id){
		$this->load->model('users_model');
		$user = $this->users_model->getUser($user_id);
		if (empty($user)){

		$this->session->set_flashdata('failure', 'Record not found in database!');
		redirect(base_url().'index.php/user/index'); 
		}

		$this->users_model->deleteUser($user_id);
		$this->session->set_flashdata('success', 'Record deleted successfully!');
		redirect(base_url().'index.php/user/index'); 
	}
}

?>
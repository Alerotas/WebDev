<!DOCTYPE html>
<html>
<head>
	<title>Application</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url().'assets/css/bootstrap.min.css';?>">


</head>
<body>
<div class="navbar navbar-dark bg-dark">
	<div class="container">
		<a href="#" class="navbar-brand">List</a>
	</div>

</div>

<div class="container" style="padding-top: 10px"> 
	<div class="row">
		<div class="col-md-12">
			<?php
			$success = $this->session->userdata('success');
			if ($success !=""){	
			 ?>
			 	<div class="alert alert-success"><?php echo $success;?> </div>
			<?php
			}
			?>	

			<?php

			$failure = $this->session->userdata('failure');
			if($failure !=""){	
			 ?>
			 	<div class="alert alert-success"><?php echo $failure;?> </div>
			<?php
			}
			?>	


		</div>
	</div>
	
	<div class="row">
		<div class="col-6"><h2> Listed Information</h2></div>
		<div class="col-6 text-right">
		<a href="<?php echo base_url().'index.php/user/create';?>" class="btn btn-primary">Create Student</a>
	</div>
	<br>
	</div>
	
	<hr>
	<div class="row">
		<div class="col-md-12">
			<table class="table table-striped">
				<tr>
					<th>EDP</th>
					<th>Name</th>
					<th>Age</th>
					<th>Status</th>
					<th><center>Email</center> </th>
					<th width="">Action</th>	
					<td></td>
				</tr>

				<?php if (!empty($tablesample))  { foreach($tablesample as $tablesample){?>

				<tr>
					<td> <?php echo $tablesample['user_id'] ?></td>
					<td> <?php echo $tablesample['name'] ?></td>
					<td> <?php echo $tablesample['age'] ?></td>
					<td> <?php echo $tablesample['status'] ?></td>
					<td> <?php echo $tablesample['email'] ?></td>

					<td>
						<a href="<?php echo base_url().'index.php/user/edit/'.$tablesample['user_id']?>" class="btn btn-primary"> Edit</a>
					</td>

					<td>
						<a href="<?php echo base_url().'index.php/user/delete/'.$tablesample['user_id']?>" class="btn btn-danger"> Delete</a>
					</td>
				</tr>


				<?php } } else {?>

				<tr>
					<td colspan="5"> Records not found</td>
				</tr>
				<?php } ?>

			</table>

		</div>
	</div>
</div>
</body>
</html>

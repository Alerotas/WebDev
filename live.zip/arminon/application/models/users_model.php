<?php
class users_model extends CI_model{
	
	
	function create($formArray)
	{
		$this->db->insert('tablesample',$formArray); // INSERT INTO tablesample (name, age, status, email, creaded) value (?,?,?, ?,?0;)

	}
function all() {
		return $user = $this->db->get('tablesample')->result_array(); // SELECT * from tablesample
	}
	function getUSer($user_id){
		$this->db->where('user_id',$user_id);
		return $user = $this->db->get('tablesample')->row_array(); // SELECT * from tablesample where user_id = ?
	}

	function updateUser($user_id,$formArray){
		$this->db->where('user_id',$user_id);
		$this->db->update('tablesample',$formArray);// UPDATE tablesample SET name = ?, age =?,status =?,email = ? where user_id =?
	}

	function deleteUser($user_id){
		$this->db->where('user_id',$user_id);
		$this->db->delete('tablesample'); // DELETE FROM tablesample where user_id = ?
	}
}
?>